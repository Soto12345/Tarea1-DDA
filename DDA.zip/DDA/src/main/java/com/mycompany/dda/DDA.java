package com.mycompany.dda;

import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class DDA extends JPanel{

    public void drawLineDDA(Graphics g, int x1, int y1, int x2, int y2) {
        int dx = x2 - x1;
        int dy = y2 - y1;

        int steps = Math.max(Math.abs(dx), Math.abs(dy));

        float xIncrement = dx / (float) steps; 
        float yIncrement = dy / (float) steps; 

        float x = x1;
        float y = y1;

        for (int i = 0; i <= steps; i++) {
            g.drawRect(Math.round(x), Math.round(y), 1, 1); 
            x += xIncrement; 
            y += yIncrement; 
        }
    }

    // Sobreescribir el método paintComponent para dibujar la línea
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawLineDDA(g, 50, 50, 250, 200); 
    }
 
    public static void main(String[] args) {
        JFrame frame = new JFrame("Algoritmo DDA");
        DDA panel = new DDA();
        frame.add(panel);
        frame.setSize(300, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
